<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tilset_Terre_01" tilewidth="32" tileheight="32" tilecount="56" columns="7">
 <image source="../tileset_png/tilset_Terre_01.png" width="224" height="256"/>
</tileset>
