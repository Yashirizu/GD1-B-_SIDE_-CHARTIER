<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tilset_03" tilewidth="32" tileheight="32" tilecount="30" columns="5">
 <image source="../tileset_png/pierre et fond.png" width="160" height="192"/>
</tileset>
