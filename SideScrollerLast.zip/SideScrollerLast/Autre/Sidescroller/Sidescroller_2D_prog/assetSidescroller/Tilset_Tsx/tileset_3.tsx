<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tileset_3" tilewidth="32" tileheight="32" tilecount="5329" columns="73">
 <image source="C:/Users/chart/Desktop/EPTA/Level Design/mon premier niveau/tileset_1.png" width="2362" height="2362"/>
</tileset>
