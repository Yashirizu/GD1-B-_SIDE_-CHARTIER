<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="arbres" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="../tileset_png/arbres.png" width="96" height="96"/>
</tileset>
