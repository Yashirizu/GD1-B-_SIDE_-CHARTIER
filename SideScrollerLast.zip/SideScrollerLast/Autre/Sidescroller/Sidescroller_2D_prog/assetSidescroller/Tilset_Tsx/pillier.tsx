<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="pillier" tilewidth="32" tileheight="32" tilecount="6" columns="2">
 <image source="../tileset_png/pillier.png" width="64" height="96"/>
</tileset>
