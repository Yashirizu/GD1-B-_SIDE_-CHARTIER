<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tiles set LD01" tilewidth="32" tileheight="32" tilecount="1296" columns="36">
 <image source="C:/Users/chart/Desktop/EPTA/Level Design/tiles set LD01.png" width="1181" height="1181"/>
</tileset>
