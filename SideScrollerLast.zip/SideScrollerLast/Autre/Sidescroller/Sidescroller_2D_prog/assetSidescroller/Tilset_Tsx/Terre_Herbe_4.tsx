<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="New Piskel (8)" tilewidth="32" tileheight="32" tilecount="36" columns="6">
 <image source="C:/Users/chart/Downloads/New Piskel (8).png" width="192" height="192"/>
</tileset>
