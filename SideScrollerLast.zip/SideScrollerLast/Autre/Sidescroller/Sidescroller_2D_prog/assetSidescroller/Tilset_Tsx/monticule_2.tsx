<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="monticule_2" tilewidth="32" tileheight="32" tilecount="12" columns="3">
 <image source="../tileset_png/monticule_2.png" width="96" height="128"/>
</tileset>
