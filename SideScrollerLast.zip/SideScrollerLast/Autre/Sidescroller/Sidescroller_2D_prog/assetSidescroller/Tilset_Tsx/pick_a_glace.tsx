<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="pick_a_glace" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="../tileset_png/pick_a_glace.png" width="64" height="64"/>
</tileset>
