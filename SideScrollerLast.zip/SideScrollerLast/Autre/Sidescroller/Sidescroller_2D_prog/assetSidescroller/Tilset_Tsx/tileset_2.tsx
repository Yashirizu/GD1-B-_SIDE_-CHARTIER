<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tileset_1" tilewidth="30" tileheight="30" tilecount="6084" columns="78">
 <grid orientation="orthogonal" width="32" height="32"/>
 <image source="C:/Users/chart/Desktop/EPTA/Level Design/mon premier niveau/tileset_1.png" width="2362" height="2362"/>
</tileset>
