var config = {
	type: Phaser.AUTO,
	width: 1600, height: 1600,

	physics: {
		default: 'arcade',
		arcade: {
			gravity: { y: 300 },
			debug: true
		}
	},
	scene: { preload: preload, create: create, update: update }
};
new Phaser.Game(config);
function preload ()
{
	this.load.tilemapTiledJSON("chemin","assets/Tileset.json");
	this.load.image("tuile", "assets/Tilset.png");
	this.load.image("world", "assets/background.png");
	this.load.spritesheet("hero","assets/perso.png",
	{frameWidth:32, frameHeight:55}
	);
	// insersion des ennemis
	this.load.gif("ennemis","bat");
	// mise en place emplacement de la vie, inventaire et nombre de pièce collecter
	this.load.image ("LifeAndCollect","menu",
	{frameWidth: 40, frameHeight: 80 });
}
	var ennemis
	var player
	var coins
	var scoreText
	var score=0
	var cursors
	var heal
	var Sword
	var pike
	var stalatite
	var BlackZone
	var playerHP = 100
function create() {
	// creation du niveau
	this.map =this.make.tilemap({
		key: "chemin"
	});
	//application des tuiles sur le niveau
	this.layer = this.map.createStaticLayer("world", tile);
	// ajouter les tuiles du tile set
	let tile = this.map.addTilesetImage("tuile", "Physique");	
	//application des collisions
	this.layer.setCollision(1);
	// ajout du héro avec sa postion sur la carte
	this.hero = this.physics.add.spritesheet (50, 450, "hero");
	// activer les rebonds (à voir)
	this.hero.setBounce(1);
	//application de la vélocité (1) = vitesse ?
	this.hero.setVelocity(1)
	// limite du monde, pour permettre à la camera de suivre le joueur
	this.cameras.main.setBounds(0, 0, 1920, 1440);
	// la caméra suit le joueur
	this.cameras.main.startFollow(this.hero);

	//déplacement du joueur
	this.cursors = this.input.keyboard.addKeys({ 'up': Phaser.Input.Keyboard.KeyCodes.UP,
	'left': Phaser.Input.Keyboard.KeyCodes.LEFT,
	'right': Phaser.Input.Keyboard.KeyCodes.RIGHT,
	'space' : Phaser.Input.Keyboard.KeyCodes.SPACE,
	})
	this.anims.create({
	key: "left",
	frames: this.anims.generateFrameNumbers("perso", { start: 0, end: 3 }),
	frameRate: 10,
	repeat: 1
	});
	this.anims.create({
	key: 'turn',
	frames: [{ key: 'perso', frame: 4 }],
	frameRate: 20
	});
	this.anims.create({
	key: 'right',
	frames: this.anims.generateFrameNumbers('perso', { start: 5, end: 8 }),
	frameRate: 10,
	repeat: -1
	});

	cursors = this.input.keyboard.createCursorKeys();

	wallJump=false
	

	scoreText=this.add.text(16,16,'score: 0',{fontSize:'32px',fill:'#000'});
	//affiche un texte à l’écran, pour le score
	coins = this.physics.add.group({
		key: 'coins', repeat: 11,
		setXY: { x: 12, y: 0, stepX: 70 }
	});
	
	coins.children.iterate(function (child) {
	
	this.physics.add.collider(coins, platforms)});

		// collisionne avec les plateformes
	this.physics.add.overlap(player, coins, collectCoins, null, this);
		//le contact perso/pièces ne génère pas de collision (overlap)
		//mais en revanche cela déclenche une fonction collectCoins
	this.physics.add.overlap(player, heal, collectHeal,null,this);
	}
	ennemis = this.physics.add.group();
	this.physics.add.collider(ennemis, platforms);
	this.physics.add.collider(player, ennemis, hitBat, null, this);



	function collectCoins(player, coins)
{
    coins.disableBody(true, true); // la pièce disparaît
    score += 1; //augmente le score de 1
    scoreText.setText('Score: ' + score); //met à jour l’affichage du score

        
	var x = (player.x < 400) ? Phaser.Math.Between(400, 800) :
	Phaser.Math.Between(0, 400);

	var ennemis = ennemis.create(x, 16, 'bat');
	ennemis.create(x, 16, 'bat');
	var ennemis = ennemis.create(x, 16, 'bat');
	ennemis.setBounce(1);
	ennemis.setCollideWorldBounds(true);
	ennemis.setVelocity(Phaser.Math.Between(-200, 200), 20);
	ennemis.allowGravity = false; //elle n’est pas soumise à la gravité
}    


	function hitennemis(player, ennemis){
	    this.physics.pause();
	    player.setTint(0xff0000);
	    player.anims.play('turn');
	    if (playerHp = 0 ){
			gameOver = true}
			else playerHP =-10
		}
	function hitpike (player, pike){
		this.physics.pause();
		player.setTint(0xff0000);
		player.anims.play('turn');
		if (playerHp = 0 ){
		gameOver = true}
		else playerHP =-10
	}
	function BlackZone (player, BlackZone){
		player.setTint(0xff0000);
		player.anims.play('turn');
		gameOver = true
	}

	function update() {
    if (this.cursors.left.isDown && wallJump == false) { //si la touche gauche est appuyée
		player.setVelocityX(-150); //alors vitesse négative en X
		player.anims.play('left', true); //et animation => gauche
	}
	else if (this.cursors.right.isDown && wallJump == false) { //sinon si la touche droite est appuyée
		player.setVelocityX(150); //alors vitesse positive en X
		player.anims.play('right', true); //et animation => droite
	}
	else { // sinon
		player.setVelocityX(0); //vitesse nulle
		player.anims.play('turn'); //animation fait face caméra
	}
	if (this.cursors.space.isDown && player.body.onFloor()) {
		//si touche haut appuyée ET que le perso touche le sol
		player.setVelocityY(-200); //alors vitesse verticale négative
		//(on saute)

	if (cursors.left.isDown) { //si la touche gauche est appuyée
		player.body.setVelocityX(160); //alors vitesse négative en X
		player.anims.play('left', true); //et animation => gauche
	}
	else if (cursors.right.isDown) { //sinon si la touche droite est appuyée
		player.setVelocityX(160); //alors vitesse positive en X
		player.anims.play('right', true); //et animation => droite
	}
	else { // sinon
		player.setVelocityX(0); //vitesse nulle
		player.anims.play('turn'); //animation fait face caméra
	}
	if (cursors.up.isDown && player.body.touching.down) {
		//si touche haut appuyée ET que le perso touche le sol
		player.setVelocityY(-330); //alors vitesse verticale négative
		//(on saute)

		//ajout d'une manette
		this.input.gamepad.once('connected', function (pad){
		controller = pad;});
		 if (game.input.gamepad.supported && game.input.gamepad.active && pad1.connected)
    {
        indicator.animations.frame = 0;
    }
    else
    {
        indicator.animations.frame = 1;
    }

    // Controle de la manette
    if (pad1.isDown(Phaser.Gamepad.XBOX360_DPAD_LEFT) || pad1.axis(Phaser.Gamepad.XBOX360_STICK_LEFT_X) < -0.1)
    {
        sprite.x--;
    }
    else if (pad1.isDown(Phaser.Gamepad.XBOX360_DPAD_RIGHT) || pad1.axis(Phaser.Gamepad.XBOX360_STICK_LEFT_X) > 0.1)
    {
        sprite.x++;
    }

    if (pad1.isDown(Phaser.Gamepad.XBOX360_DPAD_UP) || pad1.axis(Phaser.Gamepad.XBOX360_STICK_LEFT_Y) < -0.1)
    {
        sprite.y--;
    }
    else if (pad1.isDown(Phaser.Gamepad.XBOX360_DPAD_DOWN) || pad1.axis(Phaser.Gamepad.XBOX360_STICK_LEFT_Y) > 0.1)
    {
        sprite.y++;
    }

    if (pad1.justPressed(Phaser.Gamepad.XBOX360_A))
    {
        sprite.angle += 5;
    }

    if (pad1.justReleased(Phaser.Gamepad.XBOX360_B))
    {
        sprite.scale.x += 0.01;
        sprite.scale.y = sprite.scale.x;
    }

    if (pad1.connected)
    {
        var rightStickX = pad1.axis(Phaser.Gamepad.XBOX360_STICK_RIGHT_X);
        var rightStickY = pad1.axis(Phaser.Gamepad.XBOX360_STICK_RIGHT_Y);

        if (rightStickX)
        {
            sprite.x += rightStickX * 10;
        }

        if (rightStickY)
        {
            sprite.y += rightStickY * 10;
        }
    }
}

}
}

